# BaiDesk

A local-first customer support CRM/ticketing platform built with Python Flask, SQLAlchemy, SQLite, HTML, CSS and JavaScript.

## Included
- Authentication with hashed passwords and sessions
- Configurable RBAC foundation
- Customers + phone numbers + duplicate detection
- Customer 360 timeline powered by append-only activity records
- Ticketing with status, priority, assignment, departments and SLA due dates
- Ticket history and reopen-ready status model
- Public replies and internal notes
- @mentions and in-app notifications
- Department escalation with mandatory reason and accept/return/resolve workflow
- Department time tracking foundation
- Admin user/department/configuration view
- Dashboard KPIs and workload views
- Dark/light mode persisted in browser
- Attachment storage foundation
- Audit log foundation
- SQLite via SQLAlchemy, structured for PostgreSQL migration

## Run in VS Code / PowerShell

1. Open this folder in Visual Studio Code.
2. Create a virtual environment:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

3. Install dependencies:

```powershell
pip install -r requirements.txt
```

4. Optional: copy `.env.example` to `.env` and change `SECRET_KEY`.
5. Start BaiDesk:

```powershell
python run.py
```

6. Open http://127.0.0.1:5000

### Default local administrator
- Email: `admin@baidesk.local`
- Password: `Admin@123`

Change this password before using BaiDesk outside local development.

## PostgreSQL later
Set `DATABASE_URL` to a PostgreSQL SQLAlchemy URL and add the PostgreSQL driver. The application uses SQLAlchemy models rather than SQLite-specific SQL so the migration path is straightforward.

## Security notes
The included local build uses secure password hashing, HTTP-only/SameSite sessions, server-side permission checks, file-extension restrictions, and append-only activity/audit records. For production deployment, add HTTPS, CSRF protection at the form/API layer, rate limiting, a production secret, PostgreSQL, object storage for attachments, background jobs for SLA notifications, and a reverse proxy.
