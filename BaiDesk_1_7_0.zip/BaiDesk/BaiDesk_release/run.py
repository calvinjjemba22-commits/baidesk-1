import os
from app import create_app

app = create_app()

if __name__ == '__main__':
    # Development only (this PC, one user). For the team use serve.py / start_baidesk.bat.
    # Debug mode exposes an interactive debugger; keep it opt-in.
    app.run(host='127.0.0.1', port=int(os.getenv('PORT', 5000)),
            debug=os.getenv('FLASK_DEBUG', '0') == '1')
