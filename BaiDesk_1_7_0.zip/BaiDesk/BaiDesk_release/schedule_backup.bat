@echo off
rem Makes Windows run the backup every day at 18:30. RUN AS ADMINISTRATOR.
rem Afterwards, COPY the "backups" folder to another computer or a USB drive now and then.
schtasks /create /tn "BaiDesk daily backup" /tr "\"%~dp0backup_baidesk.bat\"" /sc daily /st 18:30 /ru SYSTEM /f
if errorlevel 1 (echo Failed - did you run this as administrator? & pause & exit /b 1)
echo Done. A backup will be saved every day at 18:30 in the backups folder.
pause
