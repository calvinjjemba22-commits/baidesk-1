"""Run BaiDesk for a team (production server). Use start_baidesk.bat on Windows."""
import os
import socket
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
first = None
try:
    from first_run import ensure_env
    first = ensure_env(BASE)                       # must run before the config reads .env
except OSError as exc:
    sys.exit(f'Could not write {BASE / ".env"}: {exc}')
if first:
    # A brand-new install: the administrator account is created with this one-time password and must change it.
    os.environ.setdefault('BAIDESK_ADMIN_PASSWORD', first['admin_password'])
    os.environ['BAIDESK_ADMIN_MUST_CHANGE'] = '1'

from app import create_app                          # noqa: E402
from app.config import Config                       # noqa: E402

if Config.SECRET_KEY == 'baidesk-dev-secret-change-me':
    sys.exit('Refusing to start with the default SECRET_KEY. Set a long random SECRET_KEY in .env.')

app = create_app()


def lan_address():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))           # no traffic is sent; this only picks the right network card
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return socket.gethostbyname(socket.gethostname())


if __name__ == '__main__':
    from waitress import serve
    host, port = os.getenv('HOST', '0.0.0.0'), int(os.getenv('PORT', '8000'))
    print('=' * 64)
    print(' BaiDesk is running.')
    print(f'   On this PC:        http://localhost:{port}')
    print(f'   For your team:     http://{lan_address()}:{port}')
    if first:
        note = BASE / 'instance' / 'FIRST_LOGIN.txt'
        note.parent.mkdir(exist_ok=True)
        note.write_text(f"Administrator sign-in\nEmail:    admin@baidesk.local\nPassword: {first['admin_password']}\n"
                        'You must choose your own password at first sign-in. DELETE THIS FILE afterwards.\n', encoding='utf-8')
        print('   First sign-in:     admin@baidesk.local  /  ' + first['admin_password'])
        print(f'   (also saved in {note} — delete it after you have changed the password)')
    print(' Keep this window open. Press Ctrl+C to stop.')
    print('=' * 64)
    serve(app, host=host, port=port, threads=int(os.getenv('THREADS', '24')), ident='BaiDesk',
          connection_limit=1000, channel_timeout=120)
