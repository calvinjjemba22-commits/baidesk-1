@echo off
rem Lets other computers in your office open BaiDesk. RUN AS ADMINISTRATOR (right-click > Run as administrator).
rem Only for Private/Domain networks, so it is NOT opened on public Wi-Fi.
set PORT=8000
netsh advfirewall firewall delete rule name="BaiDesk" >nul 2>&1
netsh advfirewall firewall add rule name="BaiDesk" dir=in action=allow protocol=TCP localport=%PORT% profile=private,domain
if errorlevel 1 (echo Failed - did you run this as administrator? & pause & exit /b 1)
echo Done. Port %PORT% is open to your office network.
echo If your office network is set to "Public" in Windows, change it to "Private" (Settings > Network).
pause
