# Starts BaiDesk for your team. Run from PowerShell:  .\start_baidesk.ps1
Set-Location $PSScriptRoot
if (-not (Test-Path .venv\Scripts\python.exe)) { py -3 -m venv .venv }
if (-not (Test-Path .venv\Scripts\waitress-serve.exe)) { .\.venv\Scripts\python.exe -m pip install -r requirements.txt }
while ($true) {
    .\.venv\Scripts\python.exe serve.py
    Write-Host "BaiDesk stopped. Restarting in 10 seconds (Ctrl+C to quit)..."
    Start-Sleep -Seconds 10
}
