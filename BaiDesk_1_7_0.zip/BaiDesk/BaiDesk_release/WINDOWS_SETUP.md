# Running BaiDesk for your team on a Windows PC

This sets BaiDesk up on one Windows PC that everyone else opens in their browser. Allow about 30 minutes.

> **Honest note:** the `.bat` scripts were written carefully but could only be tested on Linux while building
> this. Do the first install with someone beside you, and tell us anything that doesn't work as described.

## 1. Choose the PC
- A PC that stays **on all working hours** (ideally always on), plugged into the office network by **cable**, not Wi-Fi.
- Windows power settings: *Sleep = Never* (Settings → System → Power).
- Ask whoever manages your network to give this PC a **fixed IP address** (a "DHCP reservation"). Otherwise the web
  address you give your team may change after a restart.
- Ideally on a small UPS so a power cut doesn't switch it off mid-write.

## 2. Install
1. Install **Python 3.10 or newer** from python.org. Tick **"Add python.exe to PATH"** during setup.
2. Unzip BaiDesk to a simple folder, e.g. `C:\BaiDesk`.
3. Double-click **`start_baidesk.bat`**. The first time it sets itself up (needs internet, about a minute).
4. When it says "BaiDesk is running" it prints two addresses and a **one-time administrator password**:
   ```
   On this PC:     http://localhost:8000
   For your team:  http://192.168.x.x:8000
   First sign-in:  admin@baidesk.local  /  <generated password>
   ```
5. Open the address on this PC, sign in, and choose your own password when asked.
   Then **delete `instance\FIRST_LOGIN.txt`**.

## 3. Let the team reach it
Right-click **`open_firewall.bat` → Run as administrator.** (It only opens the port on Private/Domain networks.)
Then on another computer open `http://<the "For your team" address>:8000`. If it does not load, check that the
office network profile is "Private" and that both computers are on the same network.

## 4. Keep it running by itself
Right-click **`install_autostart.bat` → Run as administrator.** BaiDesk then starts whenever the PC starts, and
restarts itself if it ever stops.

## 5. Backups (do this on day one)
1. Right-click **`schedule_backup.bat` → Run as administrator.** A backup is saved daily at 18:30 into `backups\`
   (the newest 14 are kept).
2. **Copy the `backups` folder somewhere else** (another PC, USB drive, cloud drive) at least weekly. A backup that
   lives only on the same PC does not help if that PC fails.
3. Try a **restore once** before you rely on it: stop BaiDesk, replace `instance\baidesk.db` with `baidesk.db`
   from a backup zip, copy its `uploads` folder back, start BaiDesk.

You can also download a backup any time from **Administration → Data & backup**.

## 6. Set up your people
1. **Administration → Business hours:** set your working hours and **Holidays** (SLA clocks use these).
2. **Administration → Departments & categories:** make these match how you work, and set each department's capacity.
3. **Administration → Data & backup → Staff accounts:** import `bolga_staff_import.csv` (tick *Validate only* first).
   It creates every account, the teams and the team leads. The next page shows each person's **temporary password
   once**: download it and hand them out privately. Everyone must choose their own password at first sign-in.
4. Edit each agent's **needs/skills** and capacity under Administration → Users so auto-assign routes well.

## Things to know
- **Passwords travel unencrypted** on the office network, because this runs on plain HTTP. That is acceptable on a
  trusted wired office network, but **do not expose BaiDesk to the internet** or use it over public Wi-Fi. HTTPS
  is the next step before anything outside the office uses it.
- Accounts lock for 15 minutes after 5 wrong passwords (or 30 wrong attempts from one computer).
- To update BaiDesk later: stop it, take a backup, unzip the new version over the old folder (keep `.env`,
  `instance\`, `uploads\`, `backups\`), start it. The database upgrades itself.

## How many people can it handle?
`python tools\loadtest.py` simulates your agents on **your** PC using a throwaway database (your real data is not
touched). Results from the build machine (a *single-core* sandbox, so a real PC should do better):

| Test | Result |
|---|---|
| 50 agents, one action every ~10 s (realistic) | median 20–46 ms per action, **0 errors** |
| 50 agents, one action every ~0.3 s (harsh) | ~23 requests/s, median ~0.9 s, **0 errors** |
| 50 agents all signing in at the same second | each sign-in takes ~4 s (password hashing is deliberately slow) |

Run it on the real PC, ideally while nobody else is using it, and compare. If the harsh test shows errors or very
slow responses, tell us: the next step would be moving the database to PostgreSQL.
