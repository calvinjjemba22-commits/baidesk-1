# BaiDesk

BaiDesk is a local-first customer support CRM and ticketing platform built with Python/Flask, SQLAlchemy, SQLite and responsive HTML/CSS/JavaScript.

## BaiDesk 1.1 — Professional Support Workspace

This release keeps the original database architecture and adds a polished support-operations experience:

- Modern responsive dashboard and navigation
- Customer 360 profiles
- Global search across customers, tickets and interaction notes
- Ticket queue with status, priority, department, assignment and overdue filters
- Ticket workspace with conversation, public replies and internal notes
- Attachments on ticket comments
- SLA deadline countdown and overdue state
- Reopen/resume tickets by changing status back to an active status
- Immutable customer activity timeline
- Escalation workflow with accept, return and resolve actions
- Department-time tracking foundation
- In-app notifications and mark-all-read
- Manager reports
- Dark/light mode with browser persistence
- Admin user/role/department overview
- Server-side permission checks
- Hashed passwords and Flask sessions
- SQLite via SQLAlchemy so PostgreSQL can be introduced later

## Running it for a team (Windows)
See **WINDOWS_SETUP.md**. For development on one PC, `python run.py` still works.

## What's new in 1.4
See `CHANGELOG.md` for the full list. After upgrading, review **Administration → Business hours** (defaults: Mon–Fri 08:00–17:00 local time), add your holidays, and set **capacity** for departments and agents so auto-assign and the workload card are meaningful. Use **Administration → Data & backup** to download a backup before importing anything.

## Requirements

- Windows 10/11
- Python 3.11+ recommended
- Visual Studio Code

## Run in VS Code

Open the extracted `BaiDesk` folder in VS Code.

### PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run.py
```

Open:

`http://127.0.0.1:5000`

### Windows shortcut

You can also run:

```powershell
.\start_baidesk.ps1
```

or double-click `start_baidesk.bat`.

## Default administrator

```text
Email:    admin@baidesk.local
Password: Admin@123
```

Change this password before using BaiDesk outside local development.

## Tests

After installing dependencies:

```powershell
pytest -q
```

## Database

The application uses SQLAlchemy. The default database is:

`instance/baidesk.db`

The model layer avoids SQLite-specific SQL where practical so that the application can later move to PostgreSQL using a different `DATABASE_URL` and a proper migration system.

## Important local-development note

`python run.py` starts Flask's development server for local development only. `serve.py` (used by `start_baidesk.bat`) runs a production server with a generated secret key. Still recommended before wider use: HTTPS and a managed PostgreSQL database.
