@echo off
rem Starts BaiDesk for your whole team. Keep this window open (or use install_autostart.bat).
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo First run: setting up BaiDesk, this takes a minute...
  py -3 -m venv .venv || (echo Python 3.10+ is required: https://www.python.org/downloads/ & pause & exit /b 1)
)
if not exist .venv\Scripts\waitress-serve.exe (
  call .venv\Scripts\python.exe -m pip install -r requirements.txt || (echo Install failed - check your internet connection. & pause & exit /b 1)
)
:run
.venv\Scripts\python.exe serve.py
echo.
echo BaiDesk stopped. Restarting in 10 seconds... (close this window to stop)
timeout /t 10 /nobreak >nul
goto run
