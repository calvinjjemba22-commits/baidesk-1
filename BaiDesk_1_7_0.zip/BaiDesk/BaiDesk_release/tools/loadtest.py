"""Simulate many agents using BaiDesk at the same time.

Safe to run: it builds its OWN throwaway database in a temp folder (your real data is never touched), starts the
real production server against it, and has N virtual agents sign in, browse queues, open tickets, post replies and
update tickets. It reports speed and any errors.

    python tools\\loadtest.py                       # 50 agents, 40 seconds, realistic pace
    python tools\\loadtest.py --users 50 --pace 0.2 # a harsh stress test (agents act every ~0.2 s)
    SQLITE_WAL=0 python tools/loadtest.py           # compare without the database tuning
"""
import argparse, os, random, re, socket, statistics, subprocess, sys, tempfile, threading, time
import http.cookiejar, urllib.error, urllib.parse, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
PASSWORD = 'Load-test-1'


def build_database(folder, users, tickets_each):
    from app import create_app
    from app.extensions import db
    from app.models import User, Role, Department, Customer, Ticket, TicketStatus, Priority
    from app.timeutil import utcnow
    from datetime import timedelta
    app = create_app({'SQLALCHEMY_DATABASE_URI': f'sqlite:///{folder}/load.db', 'SECRET_KEY': 'x', 'UPLOAD_FOLDER': folder})
    mapping = {}
    with app.app_context():
        agent_role = Role.query.filter_by(name='Agent').one()
        depts = Department.query.all()
        cust = []
        for i in range(80):
            c = Customer(customer_number=f'CUS-L{i:04d}', first_name=f'Cust{i}', last_name='Load')
            db.session.add(c)
            cust.append(c)
        db.session.flush()
        st = [TicketStatus.query.filter_by(slug=s).one().id for s in ('open', 'in-progress', 'pending')]
        pr = [p.id for p in Priority.query.all()]
        n = 0
        for u in range(users):
            user = User(name=f'Agent {u}', email=f'agent{u}@load.test')
            user.set_password(PASSWORD)
            db.session.add(user)
            user.roles, user.departments = [agent_role], depts
            db.session.flush()
            ids = []
            for _ in range(tickets_each):
                n += 1
                t = Ticket(ticket_number=f'LT-{n:05d}', customer_id=random.choice(cust).id, subject=f'Load ticket {n}',
                           description='Load test.', priority_id=random.choice(pr), status_id=random.choice(st),
                           department_id=random.choice(depts).id, assigned_user_id=user.id, created_by=user.id,
                           due_at=utcnow() + timedelta(hours=random.randint(-3, 60)))
                db.session.add(t)
                db.session.flush()
                ids.append(t.id)
            mapping[user.email] = ids
        db.session.commit()
    return mapping


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Agent(threading.Thread):
    def __init__(self, base, email, ticket_ids, pace, until, stats):
        super().__init__(daemon=True)
        self.base, self.email, self.ids, self.pace, self.until, self.stats = base, email, ticket_ids, pace, until, stats
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def call(self, name, path, data=None):
        t0 = time.perf_counter()
        status, body = 0, ''
        try:
            req = urllib.request.Request(self.base + path, urllib.parse.urlencode(data).encode() if data else None)
            with self.op.open(req, timeout=60) as r:
                status, body = r.status, r.read().decode('utf-8', 'replace')
        except urllib.error.HTTPError as e:
            status = e.code
        except Exception:
            status = -1
        ms = (time.perf_counter() - t0) * 1000
        bad = status >= 500 or status == -1 or 'database is locked' in body
        self.stats.add(name, ms, bad, status)
        return body

    def csrf(self, path):
        body = self.call('csrf-page', path)
        m = re.search(r'name="_csrf" value="([^"]+)"', body)
        return m.group(1) if m else ''

    def run(self):
        self.call('login', '/login', {'email': self.email, 'password': PASSWORD, '_csrf': self.csrf('/login')})
        rnd = random.Random(self.email)
        while time.time() < self.until:
            t = rnd.choice(self.ids)
            r = rnd.random()
            if r < .30:
                self.call('queue list', '/tickets')
            elif r < .50:
                self.call('open ticket', f'/tickets/{t}')
            elif r < .60:
                self.call('dashboard', '/')
            elif r < .68:
                self.call('promises', '/promises')
            elif r < .85:
                tok = self.csrf(f'/tickets/{t}')
                self.call('WRITE reply', f'/tickets/{t}/comment', {'_csrf': tok, 'comment_type': 'PUBLIC', 'body': 'Hello, following up.'})
            else:
                tok = self.csrf(f'/tickets/{t}')
                self.call('WRITE update', f'/tickets/{t}/update', {'_csrf': tok, 'status_id': rnd.choice([1, 2, 3]), 'priority_id': rnd.choice([1, 2, 3])})
            time.sleep(rnd.uniform(self.pace * .5, self.pace * 1.5))


class Stats:
    def __init__(self):
        self.lock, self.rows, self.errors = threading.Lock(), {}, {}

    def add(self, name, ms, bad, status):
        with self.lock:
            self.rows.setdefault(name, []).append(ms)
            if bad:
                self.errors[(name, status)] = self.errors.get((name, status), 0) + 1


def pct(values, p):
    values = sorted(values)
    return values[min(len(values) - 1, int(len(values) * p))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--users', type=int, default=50)
    ap.add_argument('--seconds', type=int, default=40)
    ap.add_argument('--pace', type=float, default=2.0, help='average seconds between actions per agent (real agents: 5-30)')
    ap.add_argument('--threads', type=int, default=24, help='server worker threads')
    a = ap.parse_args()
    folder = tempfile.mkdtemp(prefix='baidesk-load-')
    print(f'Building a throwaway database for {a.users} agents ...')
    mapping = build_database(folder, a.users, 6)
    port = free_port()
    env = dict(os.environ, DATABASE_URL=f'sqlite:///{folder}/load.db', SECRET_KEY='load-test-secret-key-xxxxxxxxxxxxxxxx', UPLOAD_FOLDER=folder)
    code = f"from waitress import serve; from app import create_app; serve(create_app(), host='127.0.0.1', port={port}, threads={a.threads})"
    server = subprocess.Popen([sys.executable, '-c', code], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                socket.create_connection(('127.0.0.1', port), timeout=.5).close()
                break
            except OSError:
                time.sleep(.5)
        wal = os.environ.get('SQLITE_WAL', '1') == '1'
        print(f'{a.users} agents, ~{a.pace}s between actions, {a.seconds}s, {a.threads} server threads, WAL={"on" if wal else "OFF"}')
        stats, until = Stats(), time.time() + a.seconds
        agents = [Agent(f'http://127.0.0.1:{port}', e, ids, a.pace, until, stats) for e, ids in mapping.items()]
        t0 = time.time()
        for ag in agents:
            ag.start()
            time.sleep(.05)
        for ag in agents:
            ag.join()
        took = time.time() - t0
    finally:
        server.terminate()
    total = sum(len(v) for k, v in stats.rows.items() if k != 'csrf-page')
    print(f'\n{"action":<14}{"count":>7}{"median ms":>11}{"95th ms":>9}{"slowest":>9}')
    for name in sorted(k for k in stats.rows if k != 'csrf-page'):
        v = stats.rows[name]
        print(f'{name:<14}{len(v):>7}{statistics.median(v):>11.0f}{pct(v, .95):>9.0f}{max(v):>9.0f}')
    allv = [x for k, v in stats.rows.items() for x in v]
    errs = sum(stats.errors.values())
    print(f'\n{total} requests in {took:.0f}s = {total / took:.0f} per second. Overall median {statistics.median(allv):.0f} ms, 95th {pct(allv, .95):.0f} ms.')
    print(f'ERRORS: {errs}' + ('' if not errs else '  ' + str(stats.errors)))
    sys.exit(1 if errs else 0)


if __name__ == '__main__':
    main()
